<?php 
	//Clase paginas
	class Paginas
	{
		//Metodo o funcion qe se encarga de las vistas a mostrar en pantalla segun el "action" en la URL 
		public static function enlacesPaginasModel($enlaces)
		{
			if($enlaces == "ingresar" || $enlaces == "usuarios" || $enlaces == "salir" || $enlaces == "borrar_usuario" || $enlaces == "editar_usuario" || $enlaces == "registro")
			{
				$module =  "Views/Modules/".$enlaces.".php";
			}
			else if($enlaces == "index")
			{
				$module =  "Views/Modules/ingresar.php";
			}
			else
			{
				$module = "Views/Modules/ingresar.php";
			}
			return $module;
		}
	}
?>