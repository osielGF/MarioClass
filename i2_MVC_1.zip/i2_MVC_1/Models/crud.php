<?php
//Llamar a la conexion.php para poder hacer uso de la conexion PDO a la base de datos
require_once "conexion.php";

//Clase datos extendida de conexion para usar la conexion 
class Datos extends Conexion
{

	#Registro de usuarios 
	#-------------------------------------
	public static function registroUsuarioModel($datosModel, $tabla)
	{
		//preparacion de la operacion a realizar un INSERT 
		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (usuario, password, email) VALUES (:usuario,:password,:email)");	
		//declarando los parametros usuario password y email 
		$stmt->bindParam(":usuario", $datosModel["usuario"], PDO::PARAM_STR);
		$stmt->bindParam(":password", $datosModel["password"], PDO::PARAM_STR);
		$stmt->bindParam(":email", $datosModel["email"], PDO::PARAM_STR);
		//Ejecucion de la consulta
		if($stmt->execute())
		{
			//Si inserto bien mandara de regreso un mensaje de exito
			return "success";
		}
		else
		{
			//De lo contrario mandara mensaje de error
			return "error";
		}
		$stmt->close();
	}

	//Modelo para hacer la consulta en la tabla de un usuario recibiendo datos en array asociativo sobre el usuario, para buscar donde coindidan en algun registro
	public static function ingresoUsuarioModel($datosModel, $table)
	{
		//Preparacion de la consulta
		$statement = Conexion::conectar()->prepare("SELECT * FROM $table WHERE usuario = :usuario and password = :password");	
		//Declaracion de parametros usuario and password
		$statement->bindParam(":usuario", $datosModel["usuario"], PDO::PARAM_STR);
		$statement->bindParam(":password", $datosModel["password"], PDO::PARAM_STR);
		//Ejecucion de la consulta
		$statement->execute();
		//Asociacion de los resultados y retornandolos
		return $statement->fetch();
		//Cerrar la operacion
		$statement->close();
	}

	//Modelo para hacer una consulta a la base de datos y obtener todo sobre alguna tabla en este caso se uso para la vista de usuarios
	public static function vistaUsuariosModel($table)
	{
		//Preparacion de la consulta
		$statement = Conexion::conectar()->prepare("SELECT * FROM $table");	
		//Ejecucion de la consulta
		$statement->execute();
		//Asociacion de los resultados y retornandolos
		return $statement->fetchAll();
		//Cerrar la operacion
		$statement->close();
	}

	//Modelo para borrar un usuario recibiendo como parametros el id del usuario y la tabla a operar
	public static function borrarUsuariosModel($id, $tabla)
	{
		//Preparacion de la operacion DELETE
		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");
		//Declaracion de parametro ID
		$stmt->bindParam(":id", $id, PDO::PARAM_INT);
		//Ejeciucion de la consulta
		if($stmt->execute())
		{
			//Si es exitoso el DELETE regresa mensaje de exito
			return "success";
		}
		else
		{
			//de lo contrario regresa mensaje de error
			return "error";
		}
		//Cerrar la operacion
		$stmt->close();
	}

	//Modelo para editar un usuario recibiendo como parametros el id del usuario mas la tabla a operar
	public static function editarUsuarioModel($id, $table)
	{
		//Preparacion de la consulta donde coincida el id ke recibe la funcion
		$statement = Conexion::conectar()->prepare("SELECT * FROM $table WHERE id = :id");	
		//Declara cion de parameetro ID
		$statement->bindParam(":id", $id, PDO::PARAM_INT);
		//Ejecucion de la consulta
		$statement->execute();
		//regresar los valores asociados
		return $statement->fetch();
		//Cerrar la operacion
		$statement->close();
	}

	//Modelo para actualizar los datos de un usuario recibiendo como parametros los datos nuevos del usuario  y la tabla a operar
	public static function actualizarUsuarioModel($datosModel, $tabla)
	{
		//Preparacion deL UPDATE colocando los nuevos datos y donde el id sea el mismo
		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET usuario = :usuario, password = :password, email = :email WHERE id = :id");
		//Declaracion de parametros
		$stmt->bindParam(":usuario", $datosModel["usuario"], PDO::PARAM_STR);
		$stmt->bindParam(":password", $datosModel["password"], PDO::PARAM_STR);
		$stmt->bindParam(":email", $datosModel["email"], PDO::PARAM_STR);
		$stmt->bindParam(":id", $datosModel["id"], PDO::PARAM_INT);
		//Ejecucion de UOPDATE
		if($stmt->execute())
		{
			//Si es exitoso el UPDATE regresa menaje de exito
			return "success";
		}
		else
		{
			//De lo contrario regersa mensaje de error
			return "error";
		}
		//Cerrar operacion
		$stmt->close();
	}


}
?>