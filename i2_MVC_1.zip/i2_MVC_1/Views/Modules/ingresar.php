<?php
//ver si hay una sesion existente
  error_reporting(0);
  session_start();
  if(!$_SESSION['validar'])
  {
?>

<!-- Pagina para mostrar el formulario para iniciar sesion -->
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<section>
	<form method="post">
		<h1>LOGIN</h1>
		<!-- Formulario para llenar con los datos necesarios  para iniciar sesion -->
		<input type="text" placeholder="Username" id="txtUsername" name="txtUsername" required>
		<input type="password" placeholder="Password" id="txtPassword" name="txtPassword" required>
		<input type="submit" value="Ingresar" id="txtIngresar" name="txtIngresar">
	</form>
</section>
</body>
</html>
<?php
	//Crear objeto tipo mvcController y llamar su metodo o funcion "ingresoUsuarioController" para iniciar sesion si coinciden los datos ingresados con los existentes en la BD
	$registro = new MvcController();
	$registro -> ingresoUsuarioController();
?>
<?php
} 
else
{
	//Si si hay sesion existente mostrara este mensaje
	echo '<section><h1>YA HAY UNA SESION ACTIVA</h1></section>';
}
?>