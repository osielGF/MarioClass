
<!-- Etructura HTML -->
<!DOCTYPE html>
<html>
<head>
	<title>Registro</title>
</head>
<body>
	
<section>
	<h1>REGISTRO DE USUARIO</h1>
	<!-- Formulario para el llenado de la informacion de un nuevo usuario,llenando usuario, password, email -->
	<form method="post">
		<input type="text" placeholder="Usuario" id="txtUsuario" name="txtUsuario" required>
		<input type="password" placeholder="Contrasena" id="txtPassword" name="txtPassword" required>
		<input type="email" placeholder="Email" id="txtEmail" name="txtEmail" required>
		<input type="submit" id="txtRegistrar" name="txtRegistrar" value="Registrar" required>
	</form>
	</section>
	<?php
		//Objeto MvcController
		$registro = new MvcController();
		//Metodo o controller para registrar en la base de datos los datos del nuevo usuario si se presiono el boton "txtRegistrar"
		$registro -> registroUsuarioController();
	?>

</body>
</html>

