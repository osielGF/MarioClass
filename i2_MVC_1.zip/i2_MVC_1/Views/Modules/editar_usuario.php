<?php
//ver si hay una sesion existente
  error_reporting(0);
  session_start();
  //Si no existe siempre lo estara mandando al index que es el login
  if(!$_SESSION['validar']){
    echo "
    <script type='text/javascript'>
      window.location='index.php';
    </script>";
  } 
?>

<!-- Estructura html -->
<!DOCTYPE html>
<html>
<head>
	<title>Registro</title>
</head>
<body>

<section>
	<h1>EDITAR USUARIO</h1>
	<!-- Formulario para insertar los datos del usuario mediante el controller "editarUsuarioController" -->
	<form method="post">
		<?php
			//Objeto tipo MvcController()
			$usuario = new MvcController();
			//Metoodo para mostrar los datos del usuario a editar
			$usuario -> editarUsuarioController();
			//Metodo para actualizar los nuevos datos ingresados del usuario
			$usuario -> actualizarUsuarioController();
		?>
		<input type="submit" id="txtActualizar" name="txtActualizar" value="Actualizar" required>
	</form> 
</section>

</body>
</html>

