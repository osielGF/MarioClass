<nav>
	<ul>
		<!-- Para navegar utilizamos el metodo GET representado en el URL por el simbolo "?" -->
		<li> <a href="index.php?action=registro"> Registro </a> </li>
		<li> <a href="index.php?action=ingresar"> Ingreso </a> </li>
		<li> <a href="index.php?action=usuarios"> Usuarios </a> </li>
		<li> <a href="index.php?action=salir"> Salir </a> </li>
	</ul>
</nav>