<?php
	//Destruir la sesion
	error_reporting(0);
	session_start();
	if(isset($_SESSION["validar"])){
		session_destroy();	
	}
?>
<!-- Redireccionar al index.php que se interpreta como el login -->
<script type="text/javascript">
	window.location="index.php";
</script>