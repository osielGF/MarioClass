<?php
//ver si hay una sesion existente
  error_reporting(0);
  session_start();
  if(!$_SESSION['validar']){
    echo "
    <script type='text/javascript'>
      window.location='index.php';
    </script>";
  } 
?>

<!-- Estructura HTML -->
<<!DOCTYPE html>
<html>
<head>
	<title>Listado de Usuarios</title>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<section>
	<?php
    //objeto tipo MvcController
		$usuarios = new MvcController();
    //Metodo o controller para mostrar todos los usuarios existentes en modo de tabla
		$usuarios -> vistaUsuariosController();
    //Metodo o controller para ver si se selecciono eliminar a algun usuario
    $usuarios -> borrarUsuariosController();
	?>
</section>
</body>
</html>

