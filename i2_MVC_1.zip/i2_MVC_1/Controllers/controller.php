<?php

	class MvcController
	{
		//Llamar a la plantilla 
		public function plantilla()
		{
			//Include se utiliza para invocar el archivo con el codigo html
			include "Views/template.php";
		}

		public function enlacesPaginasController()
		{
			//Trabajar con los enlaces de las paginas
			//Validar si la variable "action" viene vacia o no, es decir, cuando se abre la pagina por primera vez se debe cargar la vista index.php

			//Si la variable "action " existe en la URL almacenamos el valor de esa variable
			if(isset( $_GET['action']))
			{
				$enlaces = $_GET['action'];
			}
			else
			{
				//Si no existe el action en la URL le asignamos "index"
				$enlaces = "index";
			}
			$respuesta = Paginas::enlacesPaginasModel($enlaces);
			//incluir  la pAgina indicada devuelta por el metodo "enlacesPaginasModel"
			include $respuesta;
	    }

	    //Metodo controller para registrar un usuario
	    public function registroUsuarioController()
	    {
	    	//Si el boton txtRegistrar fue presionado
	    	if(isset($_POST["txtRegistrar"]))
	    	{
	    		//Obtener mediante POST todos los valores de los campos del formulario llenado
	    		$datosController = array("usuario"=>$_POST["txtUsuario"],
	    								 "password"=>$_POST["txtPassword"],
	    								 "email"=>$_POST["txtEmail"]);

	    		//Mandar el array asociativo con todos los dtos del usario a registrar al metodo model "registroUsuarioModel" mandandole el array y el nombre de la tabla a operar
	    		$respuesta = Datos::registroUsuarioModel($datosController,"usuarios");

	    		//Dependiendo si fue exitosa la insercion redirige a la vista "registro"	
	    		if($respuesta == "success")
	    		{
					//ver si hay una sesion existente
					  error_reporting(0);
					  session_start();
					  if($_SESSION['validar']){
					    echo "
					    <script type='text/javascript'>
					      window.location='index.php?action=usuarios';
					    </script>";
					  } 
					  else
					  {
					  	echo '<script type="text/javascript">
									window.location.href = "index.php?action=ingresar";
								</script>'; 
					  }
	    		}
	    		//de lo contrario manda al login
	    		else
	    		{
	    			echo '<script type="text/javascript">
						window.location.href = "index.php";
					</script>'; 
	    		}
	    	}
	    }

	    //Metodo controller para realizar e login
	    public function ingresoUsuarioController()
		{
			//Si el boton txtIngresar fjue presionado se obtendRan el usuario y password ingresados por el usuario en un array asociativo	
			if(isset($_POST["txtIngresar"]))
			{	
				$datosController = array("usuario"=>$_POST["txtUsername"],
										"password"=>$_POST["txtPassword"]);
				//Se manda el array asociativo mas la tabla a operar al metodo model "ingresoUsuarioModel"
				$respuesta = Datos::ingresoUsuarioModel($datosController,"usuarios");

				//Segun la resultados devueltas por el modelo si coinciden conlos datos ingresados por el usuario inciiara sesion y re-direccionara a la vista "usuarios"
				if($respuesta["usuario"] == $_POST["txtUsername"] && $respuesta["password"] == $_POST["txtPassword"])
				{
					session_start();
					$_SESSION["validar"] = true;
					$_SESSION["usuario"] = $respuesta["usuario"];
					$_SESSION["password"] = $respuesta["password"];
					echo "<script>
							window.location='index.php?action=usuarios'
						</script>";
				}
				//de lo contrario dejara en el mismo login
				else
				{
					echo "<script>
							window.location='index.php'
						</script>";
					echo "El usuario o contraseña no coinciden";
				}
			}
		}

		//Controller para mostrar la vista de todos los usuarios imprimiendo la tabla con todos los usuarios  dando la posibilidad de editarlos o eliminarlos
		public function vistaUsuariosController()
		{
			$arrayRespuesta = Datos::vistaUsuariosModel("usuarios");
			echo '
				<table border="1px">
					<thead>
						<tr>
							<th>Id</th>
							<th>Usuario</th>
							<th>Password</th>
							<th>Email</th>
							<th>Editar?</th>
							<th>Eliminar?</th>
						</tr>
					</thead>';
			foreach($arrayRespuesta as $row => $item)
			{
			echo'
				<tbody>
					<tr>
						<td>'.$item["id"].'</td>
						<td>'.$item["usuario"].'</td>
						<td>'.$item["password"].'</td>
						<td>'.$item["email"].'</td>
						<td> <a title="Editar" href="index.php?action=editar_usuario&id='.$item["id"].'"> <button > Editar </button></a></td>
						<td> <a title="Borrar" onClick="borrar('.$item["id"].');"> <button> Borrar </button></a></td>
					</tr>
				</tbody>
				';
				echo '<script type="text/javascript">
				        var password="'.$_SESSION["password"].'";
				        function borrar(id){
				          swal("Ingrese su contraseña:", {
				            content: "input",
				          })
				          .then((value) => 
				          {
				              if (value==password) 
				              {
				                swal("Contraseña correcta", "Usuario eliminado", "success");
				                window.location.href = "index.php?action=usuarios&idBorrar="+id;
				              }
				              else
				              {
				                swal("Contraseña Incorrecta", "Intente de nuevo", "error");
				              }     
				          });
				        } 
				    </script>';
			}
		}

		//Controller para borarar un usuario, 
		public function borrarUsuariosController()
		{
			//Si en la URL existe "idBorrar" obrtendra el id a borrar
			if(isset($_GET["idBorrar"]))
			{
				$datosController = $_GET["idBorrar"];
				//Mandara el id a borrar y se lo mandara al modelo "borrarUsuariosModel" mas el nombre dd la tabla a operar
				$respuesta = Datos::borrarUsuariosModel($datosController, "usuarios");

				//Si el DELETE fue exitoso redireccionara a la vista usuarios
				if($respuesta == "success")
				{
					echo "
						    <script type='text/javascript'>
						      window.location='index.php?action=usuarios';
						    </script>";
				}
				//De lo contrario mostrara mensaje de error
				else
				{
					echo "error";
				}
			}
		}

		//Controller para editar un usuario, mostrando los datos en formulario del usuario indicado
		public function editarUsuarioController()
	    {
	    	//Se obtiene el id del usuario en la URL
	    	$datosController = $_GET["id"];
	    	//Se manda este id mas el nombre de la tabla a operar al modelo para hacer la consulta de sus datos
	    	$respuesta = Datos::editarUsuarioModel($datosController,"usuarios");
	    	//Y mostrarlos en INPUTS con los datos correspondientes al usuario
    		echo 'Usuario:<input type="text" value="'.$respuesta["usuario"].'" id="txtUsuario" name="txtUsuario" required>
	    		Password:<input type="text" value="'.$respuesta["password"].'" id="txtPassword" name="txtPassword" required>
	    		Email:<input type="email" value="'.$respuesta["email"].'" id="txtEmail" name="txtEmail" required>
	    		<input type="hidden" value="'.$datosController.'" id="txtID" name="txtID">'; 
	    }

	    //Controller para actualizar a un usuario
	    public function actualizarUsuarioController()
	    {
	    	//Si el boton txtActualizar fue lanzado entonces
	    	if(isset($_POST["txtActualizar"]))
	    	{
	    		//obtiene mediante POST todos los datos del usuario llenados en el formulario a un array asociativo "$datosController"
	    		$datosController = array("usuario"=>$_POST["txtUsuario"],
	    								 "password"=>$_POST["txtPassword"],
	    								 "email"=>$_POST["txtEmail"],
	    								 "id"=>$_POST["txtID"]);

	    		//Se manda este array mas el nombre de la tabla a operar al modelo que realizara el UPDATE 
	    		$respuesta = Datos::actualizarUsuarioModel($datosController,"usuarios");

	    		//Si el UPDATE fue exitoso entonces redireccionara a la vista usuarios
	    		if($respuesta == "success")
	    		{
	    			echo '<script type="text/javascript">
						window.location.href = "index.php?action=usuarios";
					</script>'; 
	    		}
	    		//De lo contrario mostrara un mensaje de error
	    		else
	    		{
	    			echo 'error'; 
	    		}
	    	}
	    }


	}
?>